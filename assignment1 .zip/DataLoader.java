package Assignment1;
import java.util.Arrays;
import java.util.List;

public class DataLoader implements Interface{
	/*
	 *  This is a set of hard coded data.
	 */
	@Override
	public void DataLoader() {
		Driver dl = new Driver();
		Adult Alice = new Adult("Alice", 24);
		Adult Bob = new Adult("Bob",29);
		dl.marrying(Alice,Bob);
		Adult Cathy = new Adult("Cathy", 34);
		Adult Don = new Adult("Don", 44);
		Alice.updateProfile("Rmit student");
		Bob.updateProfile("Freelance");
		Cathy.updateProfile("working at KFC");
		Don.updateProfile("umemployed");
		Dependent Eric = new Dependent("Eric",5,Alice,Bob);
		Dependent Fred = new Dependent("Fred",8,Bob,Alice);
		Eric.updateProfile("Baby");
		Fred.updateProfile("Level 2");
		dl.makeFriends(Alice, Bob);
		dl.makeFriends(Alice, Don);
		dl.makeFriends(Cathy, Don);
		dl.addPerson(Alice);
		dl.addPerson(Bob);
		dl.addPerson(Cathy);
		dl.addPerson(Don);
		dl.addPerson(Eric);
		dl.addPerson(Fred);
	}


}
