package Assignment1;
import java.util.*;

/*
 * This is the main startup class.
 * Some data is hard coded at the moment.
 */

public class MiniNet {
	
	private static final String Menu = "\n\nMiniNet Menu\n======================================\n"
			+ "1.  Add a person\n"
			+ "2.  List all people\n"
			+ "3.  Select a person by name\n"
			+ "4.  Display the profile of the selected person\n"
			+ "5.  Update the profile information of the selected person\n"
			+ "6.  Delete the selected person\n"
			+ "7.  Make two persons friends\n"
			+ "8.  Make two persons parents\n"
			+ "9.  Find out whether a person is a direct friend of another person\n"
			+ "10. Find out the childrens' name of selected person\n"
			+ "    or the names of the parents.\n"
			+ "11. Exit\n"
			+ "\n\nEnter an option: _";
	
	/*
	public static void invalidInput() {
		System.out.println("Invalid input! Please try again.");
	}
	*/
	static String invalid = "Invalid input! Please try again.";
	
	public static boolean using = true;

	
		
	
			public static void main(String[] args) {
				Driver driver = new Driver();
				driver.initation();
				String selectedPerson = null;
				while(using){
				System.out.println(Menu);
				Scanner input = new Scanner(System.in);
				try {int option = input.nextInt();
				switch(option) {
				
				case (1):
					input.nextLine();
					System.out.println("\nPlease enter your name:");
					String name = input.nextLine().trim();
					System.out.println("\nPlease enter your age:");
					int age = input.nextInt();
					input.nextLine();
					System.out.println("\nPlease enter your status:");
					String status = input.nextLine().trim();
					if (age < 0 || age >120) {
						System.out.println(invalid);}
					else if(age >= 16) {
						Adult a = new Adult(name,age);
						a.updateProfile(status);
						driver.addPerson(a);
						System.out.println(name + " has been added into Mininet.");
						} 
					
					else {
						System.out.println("\nChoose two adults as parents:");
						driver.showPeople();
						String parent1 = input.nextLine().trim();
						driver.showPeople();
						String parent2 = input.nextLine().trim();
						if(parent1.equals(parent2)) {
							System.out.println("Parents cant be same person");
							}
						else if (driver.getPerson(parent1).getMarriage().getName() ==
								driver.getPerson(parent2).getName()) 
						{
							Dependent d = new Dependent(name,age,(Adult)driver.getPerson(parent1),(Adult)driver.getPerson(parent2));
							driver.addPerson(d);
							System.out.println(name + " has been added into Mininet.");
						}
						else {
							System.out.println("Selected persons are currently not in a marriage relationship");
								}
						
					}
					break;
					
				case(2):
					//Show all people.
					driver.showPeople();
					break;
					
				case(3):
					System.out.println("\nExisting people:");
					driver.showPeople();
					System.out.println("\nPlease enter a name from list above:");
					input.nextLine();
					selectedPerson = input.nextLine().trim();
					if(driver.validateSelection(selectedPerson)) {
						System.out.println("You have selected " + selectedPerson);
					}else {
						System.out.println("\nUnable to find this person.");
						System.out.println("Please try again re-enter the correct name from the list"
								+ " \nand this application is case-sensitive.");
					}
					break;
					
					
				case(4):
					if(selectedPerson != null && driver.validateSelection(selectedPerson)) {
						driver.displayProfile(selectedPerson);
						}
					else {
						System.out.println("\nYou must select a person in order"
						+"\nto view his/her profile.");}
					break;
				
					
				case(5):
					//Update the profile information of the selected person
					if(selectedPerson != null) {
						input.nextLine();
						System.out.println("\nEnter the new status for " + selectedPerson + ":");
						status = input.nextLine();
						driver.getPerson(selectedPerson).updateProfile(status);
						System.out.println("\nSelected person's profile has been sucessfully updated");
						}
					else {
						System.out.println("\nYou must select a person in order"
						+"\nto update his/her profile.");}
					break;
					
					
				case(6):
					if(selectedPerson == null || !driver.validateSelection(selectedPerson)) {
						System.out.println("\nYou must select a person first in order"
								+"\n to delete.");
							break;}
					else {
					if(driver.getPerson(selectedPerson) instanceof Adult) {
						if(((Adult)driver.getPerson(selectedPerson)).getChildren().isEmpty()) {
							//Delete selected person from his/her friends' friendlists.
							for(String f: driver.getPerson(selectedPerson).showFriends()) {
								driver.getPerson(f).deleteFriend(selectedPerson);
								}
							driver.delete(driver.getPerson(selectedPerson));
							System.out.println(selectedPerson + " has been deleted from MiniNet.");
						}
						else {
							System.out.println(selectedPerson + " cannot be deleted while"
									+ " he/she still has children on MiniNet.");
							}
							break;
						}
					}
					break;
				
				
				case(7):
					if(selectedPerson == null || !driver.validateSelection(selectedPerson)) {
					System.out.println("\nYou must select a person first in order"
							+"\n add another person to his/her friendlist.");
						break;}
					else if(driver.validateSelection(selectedPerson)){
						System.out.println("\nMake friends between selected person and another person");
						System.out.println("\nExisting people:");
						driver.showPeople();
						System.out.println("\nPlease enter a name from list above:");
						input.nextLine();
						String selectedPerson2 = input.nextLine();
						//Check if person exists.
						if(!driver.validateSelection(selectedPerson2)) {
							System.out.println("\nCant find this person");
							System.out.println("Please try again re-enter the correct name from the list"
									+ " \nand this application is case-sensitive.");
							break;
						}
					if (selectedPerson != selectedPerson2) {
						driver.makeFriends(driver.getPerson(selectedPerson), driver.getPerson(selectedPerson2));
						System.out.println(selectedPerson + " and " + selectedPerson2 + " are friends now.");
					}
					else if(selectedPerson != selectedPerson2)
						System.out.println("Please choose another person other than yourself.");
					}
						
						break;
				
						
				case(8):
					if(selectedPerson == null || !driver.validateSelection(selectedPerson)) {
						System.out.println("\nYou must select a person first");
							break;}
					else if(driver.validateSelection(selectedPerson)){
						System.out.println("\nConnect selected person and another person with marriage.");
						System.out.println("\nExisting people:");
						driver.showPeople();
						System.out.println("\nPlease enter a name from list above:");
						input.nextLine();
						String selectedPerson2 = input.nextLine();
						//Check if person exists.
						if(!driver.validateSelection(selectedPerson2)) {
							System.out.println("\nCant find this person");
							System.out.println("Please try again re-enter the correct name from the list"
									+ " \nand this application is case-sensitive.");
							break;
						}
						if(driver.getPerson(selectedPerson).getAge() < 16 ||
								driver.getPerson(selectedPerson2).getAge() < 16){
							System.out.println("Dependents are unable to involve in marriage relationship.");
							break;
							}
						else if(selectedPerson == selectedPerson2) {
							System.out.println("Please choose another person other than yourself.");
						}
						else if (selectedPerson != selectedPerson2) {
							driver.marrying((Adult)driver.getPerson(selectedPerson), (Adult)driver.getPerson(selectedPerson2));
							System.out.println(selectedPerson + " and " + selectedPerson2 + "are parents now.");
						}
					}
					break;
				
				
				case(9):
					if(selectedPerson == null || !driver.validateSelection(selectedPerson)) {
						System.out.println("\nYou must select a person first in order"
								+"\nto check the friendship");
							break;
						}
					else if(driver.validateSelection(selectedPerson)){
					System.out.println("\nCheck friendship between selected person and another person");
					System.out.println("\nExisting people:");
					driver.showPeople();
					System.out.println("\nPlease enter a name from list above:");
					input.nextLine();
					String selectedPerson2 = input.nextLine();
					//Check if person exists.
					if(!driver.validateSelection(selectedPerson2)) {
						System.out.println("\nCant find this person");
						System.out.println("Please try again re-enter the correct name from the list"
							+ " \nand this application is case-sensitive.");
						break;
					}
					if (selectedPerson != selectedPerson2 && driver.checkFriends
							(driver.getPerson(selectedPerson), driver.getPerson(selectedPerson2))) {
						System.out.println(selectedPerson + " and " + selectedPerson2 + " are friends.");
					}
					else if(selectedPerson != selectedPerson2) {
						System.out.println("Please choose another person other than yourself.");}
					else {
						System.out.println(selectedPerson + " and " + selectedPerson2 + " are not friends.");
					}
					}
						break;
						
						
				case(10):
					if(selectedPerson != null && driver.validateSelection(selectedPerson)) {
						if(driver.getPerson(selectedPerson) instanceof Dependent) {
							System.out.println("Parents:");
							System.out.println(driver.getPerson(selectedPerson).getParents());}
						else if(driver.getPerson(selectedPerson) instanceof Adult) {
							if(((Adult)driver.getPerson(selectedPerson)).getChildren().isEmpty()) {
								System.out.println(selectedPerson + " has no children on MiniNet.");
							}
							else {
								System.out.println("Childrens:");
								for(String d:((Adult)driver.getPerson(selectedPerson)).getChildren()) {
									System.out.println(d);
								}
								break;
							}
						}
					}
					else {
						System.out.println("\nYou must select a person in order"
						+"\nto view his/her profile.");}
					break;

				
				case (11):
					using = false;
					input.close();
					break;
				default:
					System.out.println("Please enter a option from 1-11.");	
				}
				}
				// throw InputMismatchException whenever input is invalid;
				catch(InputMismatchException e){System.out.println(invalid);}
				}
				
				while(!using) {
					System.exit(0);
				}
				
					
}
}