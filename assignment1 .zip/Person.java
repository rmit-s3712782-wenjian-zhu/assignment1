package Assignment1;
import java.util.ArrayList;
import java.util.List;

public abstract class Person {

	private String name;
	private int age;
	private String photo;
	private String status;
	private List<String> friendlist = new ArrayList<>();
	
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public String getName(){
		return name;
	}
	
	public int getAge(){
		return age;
	}
	
	public String getPhoto(){
		return photo;
	}
	
	public String getStatus(){
		return status;
	}
	
	public List<String> showFriends() {
		return friendlist;
	}
	
	public void updateProfile(String status) {
		this.status = status;
	}
	

	public void addFriend(Person p) {
		this.friendlist.add(p.getName());
	}
	
	public void deleteFriend(String p) {
		this.friendlist.remove(p);
	}
	
	
	public abstract boolean ifMarried();
	public abstract Adult getMarriage();
	//For Adult class use only;

	public abstract boolean sameFamily(Dependent p1, Dependent p2);
	public abstract String getParents();
	//For Dependent class use only;

	

	
	}


