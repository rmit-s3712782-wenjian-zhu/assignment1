package Assignment1;

public class Dependent extends Person {
	
	private Adult parent1;
	private Adult parent2;

	
	public Dependent(String name, int age, Adult p1, Adult p2) {
		super(name, age);
		parent1 = p1;
		parent2 = p2;
		p1.addChild(this);
		p2.addChild(this);
	}

	
	public String getParents() {
		return parent1.getName() + " and " + parent2.getName();
	}
	
	@Override
	public boolean sameFamily(Dependent d1, Dependent d2) {
		if(d1.getParents().contains(d2.parent1.getName())) 
		{
			return true;
		}
		return false;
	}
	
	@Override
	public boolean ifMarried() {
		return false;
	}

	@Override
	public Adult getMarriage() {
		return null;
	}
	

}
