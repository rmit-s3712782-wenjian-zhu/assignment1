package Assignment1;
import java.util.*;

public class Driver {
	
	private static List<Person> People = new ArrayList<>();
	
	
	public void initation() {
		MiniNet.using = true;
		new DataLoader().DataLoader();
	}
	
	
	public List<Person> getPeople() {
		return People;
	}
	
	
	public Person getPerson(String name) {
		for(Person p:People) {
			if (p.getName().equals(name))
			{if (p instanceof Adult)
				return (Adult)p;
			else if (p instanceof Dependent)
				return (Dependent)p;
			}
			}
		return null;
		}

	
	public void displayProfile(String name) {
		//This method display the profile of selected person.
		Person p = getPerson(name);
		System.out.println("Name: " + p.getName());
		System.out.println("Age: " + p.getAge());
		System.out.println("Photo: " + p.getPhoto());
		System.out.println("Status: " + p.getStatus());
		if(p instanceof Dependent) {
			System.out.println("Parents:");
			System.out.println(p.getParents());}
		else if(p instanceof Adult && p.ifMarried()) {
			System.out.println("Married: " + p.getMarriage().getName());
			}
			System.out.println("Friend with:");
		for(String f: p.showFriends()) {
			System.out.println(f);}
	}
	
	
	public void makeFriends(Person p1, Person p2) {
		if(checkFriends(p1,p2)) {
			System.out.println(p1.getName() + " and " + p2.getName() + " are already friends.");
		}
		else {
			if(p1 instanceof Dependent && p2 instanceof Dependent ) {
				if(p1.getAge() <3 || p2.getAge() <3)
					System.out.println("Too young to have a friend");
				else if (Math.abs(p1.getAge() - p2.getAge()) > 3) {
					System.out.println("The age difference between these two young friends cannot be more than 3 years.");
				}
				//Check if two dependents are not from same family.
				else if (p1.sameFamily((Dependent)p1,(Dependent)p2)) {
					System.out.println("Dependents from same family cannot be friends");
				}
				else {
					p1.addFriend(p2);
					p2.addFriend(p1);}
					System.out.println(p1.getName() + " + " + p2.getName() + " are friends now.");
					}
			else if (p1 instanceof Adult && p2 instanceof Adult ) {
				p1.addFriend(p2);
				p2.addFriend(p1);
			}
			else {
				System.out.println("Dependent cant add Adults to his/her friendlist.");
			}
	}
	}

	
	public void showPeople(){
		for (int i = 0; i < getPeople().size(); i++) {
			System.out.println(getPeople().get(i).getName());
		}
	}
	
	
	public void marrying(Adult a1, Adult a2){
		if(a1.ifMarried() ||a2.ifMarried()) {
			System.out.println(a1.getName() + " and " + a2.getName() + "are not single.");
		}
		else {
			a1.getMarried(a2);
			a2.getMarried(a1);
			}
		}
	
	
	public void addPerson(Person a) {
		People.add(a);}
	
	
	public boolean checkFriends(Person p1,Person p2) {
		for (String f: p1.showFriends()) {
			if (f.equals(p2.getName())) {
				return true;
				}
			
			}
		return false;
	}
	
	
	//To check if selected person in the database.
	public boolean validateSelection(String s) {
		boolean validation = false;
		for (int i = 0; i < getPeople().size(); i++) {
			//Happy day.
			if (s.equals(getPeople().get(i).getName())) {
				
				validation = true;
				
				}
			}
		return validation;
	}	
	
	
	public void delete(Person person) {
		getPeople().remove(person);
	}
}




