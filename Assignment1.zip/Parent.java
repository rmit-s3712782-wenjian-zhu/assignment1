package Assignment1;

public class Parent {

}
