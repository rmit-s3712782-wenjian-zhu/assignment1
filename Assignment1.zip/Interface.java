package Assignment1;

public interface Interface {
	public void DataLoader();
}
