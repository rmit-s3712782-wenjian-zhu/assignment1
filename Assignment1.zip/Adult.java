package Assignment1;

import java.util.ArrayList;
import java.util.List;

public class Adult extends Person {
	
	private List<String> childrenlist = new ArrayList<>();
	private Adult marriedTo;
	

	public Adult(String name,int age) {
	    super(name,age);
	}

	public boolean ifMarried(){
		if (this.marriedTo != null)
			{
			return true;
			}
		else {
			return false;
			}
	}
	

	
	public void addChild(Dependent child) {
		this.childrenlist.add(child.getName());
	}
	
	public void getMarried(Adult a) {
		this.marriedTo = a;
		}
	

	public List<String> getChildren() {
	return this.childrenlist;
	}
	
	@Override
	public Adult getMarriage() {
		return this.marriedTo;
	}
	
	@Override
	public String getParents() {
		return null;
	}
	//For Dependent class use only;

	@Override
	public boolean sameFamily(Dependent p1, Dependent p2) {
		return false;
	}
	//For Dependent class use only;

}
